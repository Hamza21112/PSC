from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String


class Audit_requests(Base):
    __tablename__ = "audit_requests"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    full_name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    brand_name = Column(String, nullable=False)
    monthly_revenue = Column(String, nullable=False)
    current_acos = Column(String, nullable=False)
    file_uploaded = Column(Boolean, nullable=True, default=False, server_default='false')
    status = Column(String, nullable=True, default='pending', server_default='pending')
    created_at = Column(DateTime(timezone=True), nullable=True)