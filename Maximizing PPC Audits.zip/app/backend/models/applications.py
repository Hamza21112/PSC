from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Applications(Base):
    __tablename__ = "applications"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    brand_name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    monthly_revenue = Column(String, nullable=False)
    current_acos = Column(String, nullable=False)
    status = Column(String, nullable=True, default='pending', server_default='pending')
    created_at = Column(DateTime(timezone=True), nullable=True)