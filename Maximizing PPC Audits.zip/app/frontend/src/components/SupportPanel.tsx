import { useState } from 'react';
import { HelpCircle, X, MessageCircle, Mail, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default function SupportPanel() {
  const [isOpen, setIsOpen] = useState(false);

  const whatsappNumber = '923431035999';
  const whatsappMessage = encodeURIComponent('Hi, I need help applying for the Profitability Accelerator Program.');
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 left-6 z-50 bg-blue-600 hover:bg-blue-700 text-white rounded-full h-14 w-14 flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300"
      >
        {isOpen ? <X className="h-6 w-6" /> : <HelpCircle className="h-6 w-6" />}
      </button>

      {isOpen && (
        <Card className="fixed bottom-24 left-6 z-50 w-80 p-6 shadow-2xl animate-in slide-in-from-bottom-4 duration-300">
          <h3 className="font-semibold text-lg mb-4">Need Help?</h3>
          <div className="space-y-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <MessageCircle className="h-5 w-5 text-[#25D366]" />
              <div>
                <p className="font-medium text-sm">Help me apply</p>
                <p className="text-xs text-slate-500">Chat on WhatsApp</p>
              </div>
            </a>

            <a
              href="mailto:ops@premiersellerconsultant.com"
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <Mail className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-sm">Email support</p>
                <p className="text-xs text-slate-500">ops@premiersellerconsultant.com</p>
              </div>
            </a>

            <button
              onClick={() => window.open('https://sellercentral.amazon.com', '_blank')}
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors w-full text-left"
            >
              <FileText className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-sm">How to export reports</p>
                <p className="text-xs text-slate-500">Amazon Seller Central guide</p>
              </div>
            </button>
          </div>
        </Card>
      )}
    </>
  );
}