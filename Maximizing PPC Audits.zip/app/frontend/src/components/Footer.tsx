import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-xl mb-4">PSC</h3>
            <p className="text-slate-400 text-sm">
              Premier Seller Consultant - Helping Amazon sellers achieve profitable PPC campaigns.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-slate-400 hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/request-audit" className="text-slate-400 hover:text-white transition-colors">
                  Request Free Audit
                </Link>
              </li>
              <li>
                <a href="#privacy" className="text-slate-400 hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#terms" className="text-slate-400 hover:text-white transition-colors">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <a href="mailto:ops@premiersellerconsultant.com" className="hover:text-white transition-colors">
                  ops@premiersellerconsultant.com
                </a>
              </li>
              <li>
                <a href="https://wa.me/923431035999" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  WhatsApp: +92 343 1035999
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-sm text-slate-400">
          <p className="mb-2">
            © {new Date().getFullYear()} Premier Seller Consultant. All rights reserved.
          </p>
          <p className="text-xs">
            Disclaimer: Results vary. Audits and program acceptance are informational and not a guarantee of outcomes.
          </p>
        </div>
      </div>
    </footer>
  );
}