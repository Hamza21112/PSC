import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';

interface HeaderProps {
  sticky?: boolean;
}

export default function Header({ sticky = false }: HeaderProps) {
  const location = useLocation();
  const isAcceleratorPage = location.pathname === '/';

  const whatsappNumber = '923431035999';
  const message = encodeURIComponent('Hi, I want to learn more about PSC services.');
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${message}`;

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className={`${sticky ? 'sticky top-0 z-40' : ''} bg-white border-b border-slate-200`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="font-bold text-2xl text-blue-600">PSC</div>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {isAcceleratorPage ? (
              <>
                <button
                  onClick={() => scrollToSection('how-it-works')}
                  className="text-slate-600 hover:text-blue-600 transition-colors"
                >
                  How it works
                </button>
                <button
                  onClick={() => scrollToSection('what-we-manage')}
                  className="text-slate-600 hover:text-blue-600 transition-colors"
                >
                  What we manage
                </button>
                <button
                  onClick={() => scrollToSection('proof')}
                  className="text-slate-600 hover:text-blue-600 transition-colors"
                >
                  Proof
                </button>
                <button
                  onClick={() => scrollToSection('faq')}
                  className="text-slate-600 hover:text-blue-600 transition-colors"
                >
                  FAQ
                </button>
                <Link to="/request-audit" className="text-slate-600 hover:text-blue-600 transition-colors">
                  Request Free Audit
                </Link>
              </>
            ) : (
              <>
                <Link to="/" className="text-slate-600 hover:text-blue-600 transition-colors">
                  Home
                </Link>
                <Link to="/request-audit" className="text-slate-600 hover:text-blue-600 transition-colors">
                  Request Audit
                </Link>
              </>
            )}
          </nav>

          <div className="flex items-center gap-3">
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm" className="hidden sm:flex items-center gap-2">
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </Button>
            </a>
            {isAcceleratorPage ? (
              <Button
                onClick={() => scrollToSection('eligibility-form')}
                size="sm"
              >
                Check Eligibility
              </Button>
            ) : (
              <Link to="/request-audit">
                <Button size="sm">
                  Get Free Audit
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}