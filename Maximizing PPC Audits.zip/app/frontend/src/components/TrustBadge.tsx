import { Check } from 'lucide-react';

interface TrustBadgeProps {
  text: string;
  icon?: React.ReactNode;
}

export default function TrustBadge({ text, icon }: TrustBadgeProps) {
  return (
    <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-medium">
      {icon || <Check className="h-4 w-4" />}
      {text}
    </div>
  );
}