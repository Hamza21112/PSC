import { createClient } from '@metagptx/web-sdk';

// Create client instance
export const client = createClient();

// API helper functions
export const api = {
  // Applications (Eligibility Form)
  async submitApplication(data: {
    brand_name: string;
    email: string;
    monthly_revenue: string;
    current_acos: string;
  }) {
    try {
      // Create application in database
      const response = await client.entities.applications.create({
        data: {
          ...data,
          status: 'pending',
          created_at: new Date().toISOString(),
        },
      });

      // Send email notification
      await client.apiCall.invoke({
        url: '/api/v1/notifications/send-email',
        method: 'POST',
        data: {
          to_email: 'Hamza@premiersellerconcultant.com',
          subject: 'New Eligibility Application Received',
          body: `
Brand Name: ${data.brand_name}
Email: ${data.email}
Monthly Revenue: ${data.monthly_revenue}
Current ACOS: ${data.current_acos}
          `,
          form_type: 'application',
        },
      });

      return response.data;
    } catch (error: any) {
      const detail =
        error?.data?.detail ||
        error?.response?.data?.detail ||
        error.message ||
        'Failed to submit application';
      throw new Error(detail);
    }
  },

  // Audit Requests
  async submitAuditRequest(data: {
    full_name: string;
    email: string;
    brand_name: string;
    monthly_revenue: string;
    current_acos: string;
    file_uploaded: boolean;
  }) {
    try {
      // Create audit request in database
      const response = await client.entities.audit_requests.create({
        data: {
          ...data,
          status: 'pending',
          created_at: new Date().toISOString(),
        },
      });

      // Send email notification
      await client.apiCall.invoke({
        url: '/api/v1/notifications/send-email',
        method: 'POST',
        data: {
          to_email: 'Hamza@premiersellerconcultant.com',
          subject: 'New PPC Audit Request Received',
          body: `
Full Name: ${data.full_name}
Email: ${data.email}
Brand Name: ${data.brand_name}
Monthly Revenue: ${data.monthly_revenue}
Current ACOS: ${data.current_acos}
File Uploaded: ${data.file_uploaded ? 'Yes' : 'No'}
          `,
          form_type: 'audit_request',
        },
      });

      return response.data;
    } catch (error: any) {
      const detail =
        error?.data?.detail ||
        error?.response?.data?.detail ||
        error.message ||
        'Failed to submit audit request';
      throw new Error(detail);
    }
  },

  // Get all applications (for admin dashboard later)
  async getApplications(skip = 0, limit = 20) {
    try {
      const response = await client.entities.applications.query({
        query: {},
        sort: '-created_at',
        limit,
        skip,
      });
      return response.data;
    } catch (error: any) {
      throw new Error(error?.data?.detail || 'Failed to fetch applications');
    }
  },

  // Get all audit requests (for admin dashboard later)
  async getAuditRequests(skip = 0, limit = 20) {
    try {
      const response = await client.entities.audit_requests.query({
        query: {},
        sort: '-created_at',
        limit,
        skip,
      });
      return response.data;
    } catch (error: any) {
      throw new Error(error?.data?.detail || 'Failed to fetch audit requests');
    }
  },
};