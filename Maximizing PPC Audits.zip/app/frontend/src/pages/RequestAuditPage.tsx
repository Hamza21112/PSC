import { useState } from 'react';
import { Upload, Check, AlertCircle, TrendingDown, Target, Zap, BarChart3, Settings, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { toast } from 'sonner';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import SupportPanel from '@/components/SupportPanel';
import TrustBadge from '@/components/TrustBadge';
import { api } from '@/lib/api';

export default function RequestAuditPage() {
  const [file, setFile] = useState<File | null>(null);
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [brandName, setBrandName] = useState('');
  const [monthlyRevenue, setMonthlyRevenue] = useState('');
  const [currentAcos, setCurrentAcos] = useState('');
  const [storefront, setStorefront] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const fileExtension = selectedFile.name.split('.').pop()?.toLowerCase();
      if (fileExtension === 'csv' || fileExtension === 'xlsx') {
        setFile(selectedFile);
      } else {
        toast.error('Please upload a CSV or XLSX file');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file || !email || !fullName || !brandName || !monthlyRevenue || !currentAcos) {
      toast.error('Please fill in all required fields and upload a file');
      return;
    }

    setIsLoading(true);

    try {
      await api.submitAuditRequest({
        full_name: fullName,
        email: email,
        brand_name: brandName,
        monthly_revenue: monthlyRevenue,
        current_acos: currentAcos,
        file_uploaded: true,
      });

      setIsSubmitted(true);
      toast.success('Upload received! Check your email for the audit.');
    } catch (error: any) {
      const detail = error?.data?.detail || error?.response?.data?.detail || error.message;
      toast.error(detail || 'Failed to submit audit request. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50">
      <Header />
      <WhatsAppButton />
      <SupportPanel />

      {/* Hero Section with Upload Card */}
      <section className="container mx-auto px-6 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight">
              Running Amazon Ads but Not Making Any Money?
            </h1>
            <p className="text-xl text-slate-600">
              Upload your Amazon Search Term Report and get a free PPC audit within minutes. We'll show exactly where you're wasting spend and what to fix to move toward profit.
            </p>
            <ul className="space-y-3">
              {[
                'Wasted spend breakdown',
                'Bad keywords to negate',
                'Winning keywords to scale',
                'ACOS and TACOS insights',
                'Bid + structure issues'
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-3 text-slate-700">
                  <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">Get Your Free PPC Audit</CardTitle>
              <CardDescription>
                Upload your Search Term Report and receive actionable insights
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      placeholder="Your full name"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Work Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@brand.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="brandName">Brand Name</Label>
                    <Input
                      id="brandName"
                      placeholder="Your Amazon brand name"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="revenue">Monthly Amazon Revenue</Label>
                    <Input
                      id="revenue"
                      placeholder="e.g., $25,000"
                      value={monthlyRevenue}
                      onChange={(e) => setMonthlyRevenue(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="acos">Current ACOS (%)</Label>
                    <Input
                      id="acos"
                      placeholder="e.g., 35%"
                      value={currentAcos}
                      onChange={(e) => setCurrentAcos(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="file">Upload Search Term Report (CSV/XLSX)</Label>
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors cursor-pointer">
                      <input
                        type="file"
                        id="file"
                        accept=".csv,.xlsx"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <label htmlFor="file" className="cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                        {file ? (
                          <p className="text-sm font-medium text-slate-900">{file.name}</p>
                        ) : (
                          <p className="text-sm text-slate-600">Click to upload or drag and drop</p>
                        )}
                        <p className="text-xs text-slate-500 mt-1">30–60 days recommended. Export from Amazon Ads console.</p>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="storefront">Storefront URL (Optional)</Label>
                    <Input
                      id="storefront"
                      type="url"
                      placeholder="amazon.com/yourbrand"
                      value={storefront}
                      onChange={(e) => setStorefront(e.target.value)}
                    />
                  </div>

                  <Button type="submit" className="w-full" size="lg" disabled={isLoading}>
                    {isLoading ? 'Sending...' : 'Send My Free Audit'}
                  </Button>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div className="flex items-center gap-1">
                      <Check className="h-3 w-3 text-green-600" />
                      Free
                    </div>
                    <div className="flex items-center gap-1">
                      <Check className="h-3 w-3 text-green-600" />
                      No tool access required
                    </div>
                    <div className="flex items-center gap-1">
                      <Check className="h-3 w-3 text-green-600" />
                      No credit card
                    </div>
                    <div className="flex items-center gap-1">
                      <Check className="h-3 w-3 text-green-600" />
                      Secure upload
                    </div>
                  </div>
                </form>
              ) : (
                <div className="text-center py-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Upload received!</h3>
                  <p className="text-slate-600">
                    Your audit will be emailed within minutes.
                    <br />
                    If you don't see it, check Promotions/Spam.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Help Section */}
        <Card className="mt-12 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold text-lg mb-1">
                  Having trouble downloading or uploading your Search Term Report?
                </h3>
                <p className="text-sm text-slate-600">
                  No problem. If you're stuck at any step, a free Amazon PPC consultant can guide you through exporting the report and uploading it correctly.
                </p>
              </div>
              <Button variant="outline" className="flex-shrink-0">
                Hire help for Free
              </Button>
            </div>
            <div className="flex gap-4 mt-3 text-xs text-slate-600">
              <span className="flex items-center gap-1">
                <Check className="h-3 w-3 text-green-600" />
                No charge
              </span>
              <span className="flex items-center gap-1">
                <Check className="h-3 w-3 text-green-600" />
                No pressure
              </span>
              <span className="flex items-center gap-1">
                <Check className="h-3 w-3 text-green-600" />
                We'll help you upload the right file
              </span>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Trust Strip */}
      <section className="bg-white border-y border-slate-200 py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-wrap justify-center gap-4">
            <TrustBadge text="Free audit" />
            <TrustBadge text="No login required" />
            <TrustBadge text="Secure upload" />
            <TrustBadge text="Actionable recommendations" />
            <TrustBadge text="Built for sellers who want profit" />
            <TrustBadge text="Delivered via email" />
          </div>
        </div>
      </section>

      {/* Pain Section */}
      <section className="container mx-auto px-6 py-16 lg:py-24">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900">
            Most Sellers Don't Have an Ads Problem. They Have a Waste Problem.
          </h2>
          <p className="text-xl text-slate-600">
            If your ads are spending but profit isn't growing, the issue is usually hidden inside search terms, match types, bids, and campaign structure.
          </p>
          <div className="grid md:grid-cols-2 gap-4 text-left">
            {[
              { icon: TrendingDown, text: "You're paying for clicks that never convert" },
              { icon: Target, text: "Your best search terms aren't being scaled" },
              { icon: AlertCircle, text: "ACOS looks random because structure is weak" },
              { icon: DollarSign, text: "Bids are too high on the wrong terms" },
              { icon: Settings, text: "Negative keywords are missing or late" }
            ].map((item, index) => (
              <div key={index} className="flex items-start gap-3 p-4 bg-red-50 rounded-lg">
                <item.icon className="h-6 w-6 text-red-600 flex-shrink-0 mt-1" />
                <p className="text-slate-700">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What You Get Section */}
      <section className="bg-slate-50 py-16 lg:py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
              What You'll Receive in Your Audit
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: DollarSign,
                title: 'Wasted Spend Breakdown',
                description: 'Find where spend is leaking without sales.'
              },
              {
                icon: AlertCircle,
                title: 'Negatives to Add (Bad Keywords)',
                description: 'Clear list of terms to block.'
              },
              {
                icon: Target,
                title: 'Winners to Scale',
                description: "What's working and how to push it."
              },
              {
                icon: BarChart3,
                title: 'ACOS + TACOS Diagnosis',
                description: 'Efficiency check with plain-English meaning.'
              },
              {
                icon: Settings,
                title: 'Structure Mistakes',
                description: 'Auto vs manual, match type split, targeting gaps.'
              },
              {
                icon: Zap,
                title: 'Bid Issues',
                description: 'Where bids are choking performance or overspending.'
              }
            ].map((item, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <item.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{item.title}</CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
          <p className="text-center mt-8 text-slate-600 font-medium">
            You'll get a short email summary + a detailed audit attachment.
          </p>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-6 py-16 lg:py-24">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-12">
            How the Free Audit Works
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                image: 'https://mgx-backend-cdn.metadl.com/generate/images/920874/2026-01-20/5ca84377-ee9d-430e-b1ce-40d0839688b1.png',
                title: 'Upload your Search Term Report',
                description: '30–60 days recommended'
              },
              {
                step: '2',
                image: 'https://mgx-backend-cdn.metadl.com/generate/images/920874/2026-01-20/d0ce2669-df2a-4ea7-8eb8-165e0ed9df33.png',
                title: 'We review spend waste, winners, structure',
                description: 'and bid issues'
              },
              {
                step: '3',
                image: 'https://mgx-backend-cdn.metadl.com/generate/images/920874/2026-01-20/a3fa7e95-0804-43a3-a3be-5f4515f4a83b.png',
                title: 'We email your audit within minutes',
                description: 'summary + attachment'
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <img src={item.image} alt={`Step ${item.step}`} className="w-10 h-10" />
                </div>
                <div className="text-sm font-semibold text-blue-600 mb-2">Step {item.step}</div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-slate-600 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Second Conversion Block */}
      <section className="bg-blue-600 text-white py-16 lg:py-24">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to See What's Killing Profit?
          </h2>
          <Button
            size="lg"
            variant="secondary"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="bg-white text-blue-600 hover:bg-slate-100"
          >
            Upload Report Now
          </Button>
        </div>
      </section>

      {/* FAQ */}
      <section className="container mx-auto px-6 py-16 lg:py-24">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-12">
            Frequently Asked Questions
          </h2>
          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-left">
                What file do I need?
              </AccordionTrigger>
              <AccordionContent>
                Your Amazon Search Term Report (CSV/XLSX). 30–60 days is recommended.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2">
              <AccordionTrigger className="text-left">
                Where do I export the Search Term Report from?
              </AccordionTrigger>
              <AccordionContent>
                Amazon Ads Console → Reports → Search term report → choose date range → export.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3">
              <AccordionTrigger className="text-left">
                Is this really free?
              </AccordionTrigger>
              <AccordionContent>
                Yes. We send the audit first so you get value immediately.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4">
              <AccordionTrigger className="text-left">
                Is my data secure?
              </AccordionTrigger>
              <AccordionContent>
                Yes. Your file is used only to generate your audit and isn't shared.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5">
              <AccordionTrigger className="text-left">
                How fast will I receive it?
              </AccordionTrigger>
              <AccordionContent>
                Typically within minutes, delivered to the email you provide.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      <Footer />
    </div>
  );
}