import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { client } from '@/lib/api';

interface Application {
  id: number;
  brand_name: string;
  email: string;
  monthly_revenue: string;
  current_acos: string;
  status: string;
  created_at: string;
}

interface AuditRequest {
  id: number;
  full_name: string;
  email: string;
  brand_name: string;
  monthly_revenue: string;
  current_acos: string;
  file_uploaded: boolean;
  status: string;
  created_at: string;
}

export default function AdminDashboard() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [auditRequests, setAuditRequests] = useState<AuditRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch applications using Web SDK
      const appsResponse = await client.entities.applications.query({
        query: {},
        sort: '-created_at',
        limit: 100,
        skip: 0,
      });
      
      if (appsResponse.data?.items) {
        setApplications(appsResponse.data.items);
      }

      // Fetch audit requests using Web SDK
      const auditsResponse = await client.entities.audit_requests.query({
        query: {},
        sort: '-created_at',
        limit: 100,
        skip: 0,
      });
      
      if (auditsResponse.data?.items) {
        setAuditRequests(auditsResponse.data.items);
      }
    } catch (error: any) {
      console.error('Error fetching data:', error);
      const detail = error?.data?.detail || error?.response?.data?.detail || error.message;
      toast.error(detail || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (type: 'application' | 'audit', id: number, newStatus: string) => {
    try {
      if (type === 'application') {
        await client.entities.applications.update({
          id,
          data: { status: newStatus },
        });
      } else {
        await client.entities.audit_requests.update({
          id,
          data: { status: newStatus },
        });
      }
      
      toast.success('Status updated successfully');
      fetchData();
    } catch (error: any) {
      console.error('Error updating status:', error);
      const detail = error?.data?.detail || error?.response?.data?.detail || error.message;
      toast.error(detail || 'Failed to update status');
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      pending: 'secondary',
      approved: 'default',
      rejected: 'destructive',
      contacted: 'outline',
    };
    return <Badge variant={variants[status] || 'default'}>{status}</Badge>;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage applications and audit requests</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Total Applications</CardTitle>
              <CardDescription>Accelerator Program</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{applications.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Audit Requests</CardTitle>
              <CardDescription>Free PPC Audits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{auditRequests.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Pending Review</CardTitle>
              <CardDescription>Requires Action</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {applications.filter(a => a.status === 'pending').length + 
                 auditRequests.filter(a => a.status === 'pending').length}
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="applications" className="space-y-6">
          <TabsList>
            <TabsTrigger value="applications">Applications</TabsTrigger>
            <TabsTrigger value="audits">Audit Requests</TabsTrigger>
          </TabsList>

          <TabsContent value="applications">
            <Card>
              <CardHeader>
                <CardTitle>Accelerator Program Applications</CardTitle>
                <CardDescription>Manage eligibility applications</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Brand Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Monthly Revenue</TableHead>
                      <TableHead>Current ACoS</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {applications.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-gray-500">
                          No applications yet
                        </TableCell>
                      </TableRow>
                    ) : (
                      applications.map((app) => (
                        <TableRow key={app.id}>
                          <TableCell>{app.id}</TableCell>
                          <TableCell className="font-medium">{app.brand_name}</TableCell>
                          <TableCell>{app.email}</TableCell>
                          <TableCell>{app.monthly_revenue}</TableCell>
                          <TableCell>{app.current_acos}</TableCell>
                          <TableCell>{getStatusBadge(app.status)}</TableCell>
                          <TableCell>{formatDate(app.created_at)}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {app.status === 'pending' && (
                                <>
                                  <Button
                                    size="sm"
                                    onClick={() => updateStatus('application', app.id, 'approved')}
                                  >
                                    Approve
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => updateStatus('application', app.id, 'rejected')}
                                  >
                                    Reject
                                  </Button>
                                </>
                              )}
                              {app.status === 'approved' && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateStatus('application', app.id, 'contacted')}
                                >
                                  Mark Contacted
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audits">
            <Card>
              <CardHeader>
                <CardTitle>Free PPC Audit Requests</CardTitle>
                <CardDescription>Manage audit submissions</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Full Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Brand Name</TableHead>
                      <TableHead>Monthly Revenue</TableHead>
                      <TableHead>Current ACoS</TableHead>
                      <TableHead>File Uploaded</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditRequests.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center text-gray-500">
                          No audit requests yet
                        </TableCell>
                      </TableRow>
                    ) : (
                      auditRequests.map((audit) => (
                        <TableRow key={audit.id}>
                          <TableCell>{audit.id}</TableCell>
                          <TableCell className="font-medium">{audit.full_name}</TableCell>
                          <TableCell>{audit.email}</TableCell>
                          <TableCell>{audit.brand_name}</TableCell>
                          <TableCell>{audit.monthly_revenue}</TableCell>
                          <TableCell>{audit.current_acos}</TableCell>
                          <TableCell>
                            {audit.file_uploaded ? (
                              <Badge variant="default">Yes</Badge>
                            ) : (
                              <Badge variant="secondary">No</Badge>
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(audit.status)}</TableCell>
                          <TableCell>{formatDate(audit.created_at)}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {audit.status === 'pending' && (
                                <>
                                  <Button
                                    size="sm"
                                    onClick={() => updateStatus('audit', audit.id, 'approved')}
                                  >
                                    Approve
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => updateStatus('audit', audit.id, 'rejected')}
                                  >
                                    Reject
                                  </Button>
                                </>
                              )}
                              {audit.status === 'approved' && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateStatus('audit', audit.id, 'contacted')}
                                >
                                  Mark Contacted
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}