import { useState, useEffect } from 'react';
import { Check, X, TrendingUp, Shield, Users, Clock, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { toast } from 'sonner';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import SupportPanel from '@/components/SupportPanel';
import { api } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function AcceleratorPage() {
  const [showExitIntent, setShowExitIntent] = useState(false);
  const [hasShownExitIntent, setHasShownExitIntent] = useState(false);
  const [spotsRemaining, setSpotsRemaining] = useState(7);

  // Form states
  const [monthlyRevenue, setMonthlyRevenue] = useState('');
  const [currentAcos, setCurrentAcos] = useState('');
  const [email, setEmail] = useState('');
  const [brandName, setBrandName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Exit intent detection
  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !hasShownExitIntent) {
        setShowExitIntent(true);
        setHasShownExitIntent(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [hasShownExitIntent]);

  // Simulate spots countdown (in production, this would come from your backend)
  useEffect(() => {
    const interval = setInterval(() => {
      setSpotsRemaining(prev => {
        if (prev > 3) {
          return Math.max(3, prev - Math.floor(Math.random() * 2));
        }
        return prev;
      });
    }, 300000); // Update every 5 minutes

    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!monthlyRevenue || !currentAcos || !email || !brandName) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);

    try {
      await api.submitApplication({
        brand_name: brandName,
        email: email,
        monthly_revenue: monthlyRevenue,
        current_acos: currentAcos,
      });

      setIsSubmitted(true);
      toast.success('Application submitted! We\'ll review and contact you within 24 hours.');
    } catch (error: any) {
      const detail = error?.data?.detail || error?.response?.data?.detail || error.message;
      toast.error(detail || 'Failed to submit application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const scrollToForm = () => {
    const form = document.getElementById('eligibility-form');
    if (form) {
      form.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50">
      <Header sticky />
      <WhatsAppButton />
      <SupportPanel />

      {/* Exit Intent Popup */}
      <Dialog open={showExitIntent} onOpenChange={setShowExitIntent}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl">Wait! Don't Miss Your Chance</DialogTitle>
            <DialogDescription className="text-base pt-2">
              Don't miss your chance to get free PPC management. Check eligibility in 60 seconds.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 pt-4">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Check className="h-4 w-4 text-green-600" />
              <span>Only {spotsRemaining} spots left this quarter</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Check className="h-4 w-4 text-green-600" />
              <span>No upfront cost</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Check className="h-4 w-4 text-green-600" />
              <span>Pay only after results</span>
            </div>
            <Button onClick={() => { setShowExitIntent(false); scrollToForm(); }} size="lg" className="w-full">
              Check Eligibility Now
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Urgency Banner */}
      <section className="bg-gradient-to-r from-red-600 to-orange-600 text-white py-4">
        <div className="container mx-auto px-6">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-center">
            <Clock className="h-5 w-5 animate-pulse" />
            <p className="font-semibold text-lg">
              Only {spotsRemaining} Spots Available This Quarter!
            </p>
          </div>
        </div>
      </section>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-16 lg:py-24">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h1 className="text-4xl lg:text-6xl font-bold text-slate-900 leading-tight">
            Get Results-Driven Amazon PPC Management (Pay After Success)
          </h1>
          <p className="text-xl lg:text-2xl text-slate-600">
            Apply for the Profitability Accelerator Program. If approved, we'll manage your PPC at no upfront cost. Pay only when we achieve measurable results.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button size="lg" onClick={scrollToForm} className="text-lg px-8">
              Check If You Qualify
            </Button>
            <Button size="lg" variant="outline" onClick={() => {
              const section = document.getElementById('how-it-works');
              section?.scrollIntoView({ behavior: 'smooth' });
            }} className="text-lg px-8">
              Learn More
            </Button>
          </div>
          <div className="flex flex-wrap justify-center gap-6 pt-6 text-sm text-slate-600">
            <div className="flex items-center gap-2">
              <Check className="h-5 w-5 text-green-600" />
              <span>No upfront cost</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-5 w-5 text-green-600" />
              <span>Pay after results</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-5 w-5 text-green-600" />
              <span>Limited to {spotsRemaining} brands this quarter</span>
            </div>
          </div>
        </div>
      </section>

      {/* Why Offer Free PPC Management Section */}
      <section className="bg-white py-16 lg:py-24 border-y border-slate-200">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-8">
              Why Offer Free PPC Management?
            </h2>
            <p className="text-xl text-slate-600 text-center mb-12">
              We offer a risk-free, performance-based program. We onboard brands we believe we can help. You pay only after you see results.
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle>Limited to 10 Brands Per Quarter</CardTitle>
                  <CardDescription>
                    We carefully select brands to ensure we can dedicate the time and resources needed for success.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle>Eligibility-Based</CardTitle>
                  <CardDescription>
                    Only the brands we can help. We review your metrics to ensure mutual success.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-2 border-blue-200">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <TrendingUp className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle>Results-Driven</CardTitle>
                  <CardDescription>
                    You pay only when we deliver measurable improvements to your PPC performance.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Client Reviews Section */}
      <section className="container mx-auto px-6 py-16 lg:py-24" id="proof">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-4">
            What Our Clients Are Saying
          </h2>
          <p className="text-center text-slate-600 mb-12">Real reviews from satisfied clients on Upwork</p>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-gradient-to-br from-blue-50 to-white">
              <CardHeader>
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <CardDescription className="text-base text-slate-700">
                  "Aamir and his team have really good knowledge in Amazon PPC, exactly what I required for my project. Keeping me up to date and telling me how to proceed in specific situations is the key thing I always needed. Thank you!"
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-slate-900">— Upwork Client</p>
                <p className="text-sm text-slate-500">Verified Review</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-white">
              <CardHeader>
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <CardDescription className="text-base text-slate-700">
                  "PSC is an excellent team. They are interested in your goals and concerns. They also demonstrate integrity and honesty during their time with me. I highly recommend them to anyone seeking to scale their business to the next level on Amazon."
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-slate-900">— Upwork Client</p>
                <p className="text-sm text-slate-500">Verified Review</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-slate-50 py-16 lg:py-24" id="how-it-works">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-12">
              How the Program Works
            </h2>
            <div className="space-y-8">
              {[
                {
                  step: '1',
                  title: 'Apply & Get Reviewed',
                  description: 'Submit your brand details. We review your current PPC performance and determine if we can help.'
                },
                {
                  step: '2',
                  title: 'We Manage Your PPC (Free)',
                  description: 'If approved, we take over your PPC management at no upfront cost. We optimize campaigns, keywords, bids, and structure.'
                },
                {
                  step: '3',
                  title: 'See Results, Then Pay',
                  description: 'Once we achieve measurable improvements (lower ACOS, higher sales, better ROI), you pay our fee. No results = no payment.'
                }
              ].map((item, index) => (
                <div key={index} className="flex gap-6 items-start">
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-xl">
                    {item.step}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-slate-900 mb-2">{item.title}</h3>
                    <p className="text-slate-600">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* What We Manage Section */}
      <section className="container mx-auto px-6 py-16 lg:py-24" id="what-we-manage">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-12">
            What We Manage
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              'Campaign structure optimization',
              'Keyword research and targeting',
              'Bid management and automation',
              'Negative keyword management',
              'Product targeting strategies',
              'Search term report analysis',
              'ACOS and TACOS optimization',
              'Monthly performance reporting'
            ].map((item, index) => (
              <div key={index} className="flex items-start gap-3 p-4 bg-white rounded-lg border border-slate-200">
                <Check className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-slate-700">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Eligibility Criteria Section */}
      <section className="bg-blue-600 text-white py-16 lg:py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold text-center mb-8">
              Check If You Qualify for Free PPC Management
            </h2>
            <p className="text-xl text-center mb-12 text-blue-100">
              We only onboard brands we believe we can help. Apply for the Profitability Accelerator Program and pay only after we deliver results.
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold mb-4">✓ You're a Good Fit If:</h3>
                {[
                  'Monthly revenue: $10K–$100K+',
                  'Current ACOS: 30%+',
                  'Running Amazon PPC ads',
                  'Want to scale profitably'
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Check className="h-5 w-5 flex-shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-semibold mb-4">✗ Not a Fit If:</h3>
                {[
                  'Monthly revenue under $10K',
                  'Not running PPC ads yet',
                  'Looking for instant results',
                  'Not willing to share data'
                ].map((item, index) => (
                  <div key={index} className="flex items-center gap-3 text-blue-100">
                    <X className="h-5 w-5 flex-shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Eligibility Form Section */}
      <section className="container mx-auto px-6 py-16 lg:py-24" id="eligibility-form">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-3xl text-center">Apply for the Program</CardTitle>
              <CardDescription className="text-center text-base">
                Fill out this quick form to see if you qualify. We'll review and get back to you within 24 hours.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="brandName">Brand Name</Label>
                    <Input
                      id="brandName"
                      placeholder="Your Amazon brand name"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@brand.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="revenue">Monthly Amazon Revenue</Label>
                    <Input
                      id="revenue"
                      placeholder="e.g., $25,000"
                      value={monthlyRevenue}
                      onChange={(e) => setMonthlyRevenue(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="acos">Current ACOS (%)</Label>
                    <Input
                      id="acos"
                      placeholder="e.g., 35%"
                      value={currentAcos}
                      onChange={(e) => setCurrentAcos(e.target.value)}
                      required
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? 'Submitting...' : 'Submit Application'}
                  </Button>

                  <p className="text-xs text-center text-slate-500">
                    By submitting, you agree to be contacted about the program. We respect your privacy.
                  </p>
                </form>
              ) : (
                <div className="text-center py-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-semibold mb-2">Application Submitted!</h3>
                  <p className="text-slate-600 mb-4">
                    Thank you for applying. We'll review your information and contact you within 24 hours.
                  </p>
                  <p className="text-sm text-slate-500">
                    Check your email (including spam folder) for our response.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-slate-50 py-16 lg:py-24" id="faq">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 text-center mb-12">
              Frequently Asked Questions
            </h2>
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-left">
                  Is this really free?
                </AccordionTrigger>
                <AccordionContent>
                  Yes, there's no upfront cost. We manage your PPC for free until we achieve measurable results. Once we improve your performance (lower ACOS, higher sales, better ROI), you pay our fee. No results = no payment.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger className="text-left">
                  Why only 10 brands per quarter?
                </AccordionTrigger>
                <AccordionContent>
                  We limit our intake to ensure each brand gets dedicated attention and resources. Quality over quantity means better results for you.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger className="text-left">
                  What if I don't qualify?
                </AccordionTrigger>
                <AccordionContent>
                  If you don't meet the criteria now, we can provide recommendations to help you reach the threshold. We may also offer alternative services.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger className="text-left">
                  How long does it take to see results?
                </AccordionTrigger>
                <AccordionContent>
                  Most brands see initial improvements within 30-60 days. Significant results typically appear within 90 days as optimizations compound.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger className="text-left">
                  What data do you need access to?
                </AccordionTrigger>
                <AccordionContent>
                  We need access to your Amazon Ads account and Seller Central for performance data. We never share your data and use it solely for optimization.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger className="text-left">
                  Can I cancel anytime?
                </AccordionTrigger>
                <AccordionContent>
                  Yes, there's no long-term contract. If you're not satisfied, you can end the program at any time with no penalties.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-16 lg:py-24">
        <div className="container mx-auto px-6 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full text-sm font-semibold mb-4">
              <Clock className="h-4 w-4" />
              Only {spotsRemaining} spots left this quarter
            </div>
            <h2 className="text-3xl lg:text-5xl font-bold">
              Ready to Scale Your Amazon PPC Profitably?
            </h2>
            <p className="text-xl text-blue-100">
              Apply now and pay only after we deliver results. No upfront cost, no risk.
            </p>
            <Button
              size="lg"
              variant="secondary"
              onClick={scrollToForm}
              className="text-lg px-8 bg-white text-blue-600 hover:bg-slate-100"
            >
              Check If You Qualify Now
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}