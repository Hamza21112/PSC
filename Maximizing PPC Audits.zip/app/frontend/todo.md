# PSC Landing Pages - Development Plan

## Design Guidelines

### Design References (Primary Inspiration)
- **audit.impactwolves.com**: Clean, professional, conversion-focused
- **Modern SaaS Landing Pages**: Stripe, Linear, Vercel
- **Style**: Clean Minimalism + Professional + High Conversion

### Color Palette
- Primary: #2563eb (Professional Blue - CTAs and highlights)
- Secondary: #1e40af (Darker Blue - hover states)
- Background: #ffffff (White - main background)
- Surface: #f8fafc (Light Gray - cards/sections)
- Text Primary: #0f172a (Slate 900)
- Text Secondary: #64748b (Slate 500)
- Success: #10b981 (Green - confirmations)
- Border: #e2e8f0 (Slate 200)

### Typography
- Heading1: Inter font-weight 700 (48px) - Hero headlines
- Heading2: Inter font-weight 600 (36px) - Section titles
- Heading3: Inter font-weight 600 (24px) - Subsections
- Body/Normal: Inter font-weight 400 (16px)
- Body/Emphasis: Inter font-weight 600 (16px)
- Small: Inter font-weight 400 (14px)

### Key Component Styles
- **Primary Buttons**: Blue background (#2563eb), white text, 8px rounded, hover: darken to #1e40af, shadow on hover
- **Secondary Buttons**: White background, blue border, blue text, hover: light blue background
- **Cards**: White background, subtle shadow (0 1px 3px rgba(0,0,0,0.1)), 12px rounded, hover: lift with increased shadow
- **Forms**: Clean inputs with border, focus: blue ring, proper spacing
- **Trust Badges**: Small pills with light background, icon + text

### Layout & Spacing
- Hero section: Full viewport height with centered content
- Max content width: 1200px
- Section padding: 80px vertical, 24px horizontal
- Card spacing: 24px gaps in grids
- Button padding: 12px 24px

### Images to Generate
1. **hero-audit-dashboard.jpg** - Clean dashboard showing PPC metrics and insights, professional style (Style: photorealistic, modern UI)
2. **hero-accelerator-team.jpg** - Professional team working on Amazon PPC campaigns, collaborative atmosphere (Style: photorealistic, business professional)
3. **trust-badge-secure.png** - Shield icon representing secure data upload (Style: minimalist icon, blue accent)
4. **trust-badge-free.png** - Gift/star icon representing free service (Style: minimalist icon, blue accent)
5. **step-upload-icon.png** - Upload cloud icon for step 1 (Style: minimalist icon, blue accent)
6. **step-review-icon.png** - Magnifying glass/analysis icon for step 2 (Style: minimalist icon, blue accent)
7. **step-deliver-icon.png** - Email/checkmark icon for step 3 (Style: minimalist icon, blue accent)
8. **whatsapp-support.png** - WhatsApp logo/icon for floating button (Style: official WhatsApp green, clean)

---

## Development Tasks

### 1. Project Setup & Structure
- Update index.html with proper meta tags and title
- Create routing structure for two pages
- Set up shared components folder

### 2. Generate All Images
- Use ImageCreator.generate_images to create all 8 images following design guidelines
- Store in public/assets/ directory

### 3. Shared Components
- Header component with navigation and CTAs
- Footer component with privacy, terms, contact
- WhatsApp floating button component
- Support panel component
- Trust badge component
- Form input components

### 4. Free PPC Audit Page (/audit)
- Hero section with headline, subheadline, bullets, and upload form card
- Trust strip with badges
- Pain section with problem agitation
- "What You Get" section with 6 deliverable cards
- "How It Works" 3-step process
- Second conversion block with repeat upload form
- FAQ section with 5 key questions
- Footer

### 5. Profitability Accelerator Page (/)
- Sticky header with navigation
- Hero section with eligibility form preview
- "Why Free" section
- "How It Works" 3 steps
- "What We Manage" scope clarity section
- "Who This Is For / Not For" qualification section
- Proof section with placeholder testimonials
- Main CTA section with eligibility hook
- FAQ section
- Exit-intent popup component
- 2-step eligibility form modal

### 6. Form Handling & Validation
- File upload validation (CSV/XLSX only)
- Email validation
- Form submission success states
- Email notification setup to ops@premiersellerconsultant.com

### 7. Interactive Features
- WhatsApp floating button with auto-message template
- Support icon with help panel
- Exit-intent popup (desktop only)
- Smooth scroll to sections
- Form step transitions

### 8. Responsive Design & Polish
- Mobile-responsive layouts
- Touch-friendly buttons and forms
- Optimized images
- Loading states
- Error handling

### 9. Testing & Optimization
- Cross-browser testing
- Form submission testing
- Mobile responsiveness
- Performance optimization

### 10. Final Check
- Run lint and build
- Verify all links and forms
- Check all copy matches requirements
- Ensure WhatsApp integration works